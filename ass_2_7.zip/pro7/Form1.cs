﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pro7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
        }

        private void btntime_Click(object sender, EventArgs e)
        {
            //txttimer.Text = System.DateTime.Now.ToString();
            txttime.Text = System.DateTime.Now.ToString();

        }
    }
}
