﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pro8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlog_Click(object sender, EventArgs e)
        {
            String User = "Krish2105";
            String pass = "Krish2105";
            String Message = "";
            if (txtuser.Text.Length > 10)
            {
                Message = Message + "Username must be less then or equal to 10 cheracters.";
            }
            if(txtpass.Text.Length <5 || txtpass.Text.Length >12)
            {
                Message = Message + "\nPassword Length must be between 5 to 12 charecters.";
            }

            if(txtuser.Text == User && txtpass.Text == pass) {
                Message = Message + "Login Succesfully";
            }
            else
            {
                Message = "\nEnter Valid Username And Password.";
            }
            MessageBox.Show(Message);
        }
    }
}
