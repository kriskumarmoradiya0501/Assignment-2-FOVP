﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace pro9
{
    public partial class Form1 : Form
    {
        string query;
        SqlConnection conn;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\.net\\22bca136\\ass_2_9_db\\Ass_2_9_db.mdf;Integrated Security=True;Connect Timeout=30";
            conn = new SqlConnection(connstring);
            conn.Open();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtproname.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtproname.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtproprice.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtproprice.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtquality.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtquality.Focus();
                return;
            }
            else
            {
                query = "INSERT INTO Product(Pname, PPrice, PQty) VALUES (@Pname, @PPrice, @PQty)";
                cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Pname", txtproname.Text);
                cmd.Parameters.AddWithValue("@PPrice", Convert.ToInt32(txtproprice.Text));
                cmd.Parameters.AddWithValue("@PQty", Convert.ToInt32(txtquality.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Inserted...");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtproname.Text))
            {
                MessageBox.Show("Enter Product Name : ");
                txtproname.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtproprice.Text))
            {
                MessageBox.Show("Enter Product Price : ");
                txtproprice.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtquality.Text))
            {
                MessageBox.Show("Enter Product Quantity : ");
                txtquality.Focus();
                return;
            }
            else
            {
                query = "UPDATE Product SET Pname = @Pname, PPrice = @PPrice, PQty = @PQty WHERE PId = @PId";
                cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Pname", txtproname.Text);
                cmd.Parameters.AddWithValue("@PPrice", Convert.ToInt32(txtproprice.Text));
                cmd.Parameters.AddWithValue("@PQty", Convert.ToInt32(txtquality.Text));
                cmd.Parameters.AddWithValue("@PId", Convert.ToInt32(comboBox1.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated...");
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            query = "DELETE FROM Product WHERE PId = @PId";
            cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@PId", Convert.ToInt32(comboBox1.Text));
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted...");
        }

        private void btnview_Click(object sender, EventArgs e)
        {
            query = "SELECT PId FROM Product";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "PId";
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            query = "SELECT Pname, PPrice, PQty FROM Product";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dg1.DataSource = dt;
        }

        private void txtproname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtproprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtquality_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBox1.Text))
            {
                query = "SELECT * FROM Product WHERE PId = @PId";
                cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PId", Convert.ToInt32(comboBox1.Text));
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    txtproname.Text = dr["Pname"].ToString();
                    txtproprice.Text = dr["PPrice"].ToString();
                    txtquality.Text = dr["PQty"].ToString();
                }
                dr.Close();
            }
            else
            {
                MessageBox.Show("Please select a valid Product ID.");
            }
        }
    }
}
