﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnpreview_Click(object sender, EventArgs e)
        {
            String name = "",Country = "",Gender = "",Hobbies = "",status = "";
            name = name+txtname.Text;
            Country = Country+chlcountry.Text;
            if (rbfemale.Checked )
            {
                Gender = Gender + "Female";
            }
            if (rbmale.Checked ) {
                Gender = Gender + "Male";
            }
            if (chkreading.Checked ) {
                Hobbies = Hobbies + " " + "Reading";
            }
            if (chkpainting.Checked ) {
                Hobbies = Hobbies + " " + "Painting";
            }
            if (rbmarried.Checked)
            {
                status = status + "Married";
            }
            if(rbunmarried.Checked )
            {
                status = status + "Unmarried";
            }
            MessageBox.Show("Name : " + name + "\nCountry :" + Country + "\nGender : " + Gender + "\nHobbies = " + Hobbies + "\nStatus : " + status);
        }
    }
}
