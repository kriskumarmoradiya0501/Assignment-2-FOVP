﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.chlcountry = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbfemale = new System.Windows.Forms.RadioButton();
            this.rbmale = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbunmarried = new System.Windows.Forms.RadioButton();
            this.rbmarried = new System.Windows.Forms.RadioButton();
            this.btnpreview = new System.Windows.Forms.Button();
            this.chkreading = new System.Windows.Forms.CheckBox();
            this.chkpainting = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Namer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Country";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(152, 41);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(144, 20);
            this.txtname.TabIndex = 2;
            // 
            // chlcountry
            // 
            this.chlcountry.FormattingEnabled = true;
            this.chlcountry.Items.AddRange(new object[] {
            "India",
            "intaly",
            "russia",
            "canada",
            "Usa",
            "UAE",
            "UK"});
            this.chlcountry.Location = new System.Drawing.Point(152, 85);
            this.chlcountry.Name = "chlcountry";
            this.chlcountry.Size = new System.Drawing.Size(144, 21);
            this.chlcountry.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbfemale);
            this.groupBox1.Controls.Add(this.rbmale);
            this.groupBox1.Location = new System.Drawing.Point(35, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(261, 44);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gender";
            // 
            // rbfemale
            // 
            this.rbfemale.AutoSize = true;
            this.rbfemale.Location = new System.Drawing.Point(157, 19);
            this.rbfemale.Name = "rbfemale";
            this.rbfemale.Size = new System.Drawing.Size(59, 17);
            this.rbfemale.TabIndex = 0;
            this.rbfemale.TabStop = true;
            this.rbfemale.Text = "Female";
            this.rbfemale.UseVisualStyleBackColor = true;
            // 
            // rbmale
            // 
            this.rbmale.AutoSize = true;
            this.rbmale.Location = new System.Drawing.Point(20, 19);
            this.rbmale.Name = "rbmale";
            this.rbmale.Size = new System.Drawing.Size(48, 17);
            this.rbmale.TabIndex = 0;
            this.rbmale.TabStop = true;
            this.rbmale.Text = "Male";
            this.rbmale.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Hobbies";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbunmarried);
            this.groupBox2.Controls.Add(this.rbmarried);
            this.groupBox2.Location = new System.Drawing.Point(38, 226);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(258, 46);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Status";
            // 
            // rbunmarried
            // 
            this.rbunmarried.AutoSize = true;
            this.rbunmarried.Location = new System.Drawing.Point(154, 19);
            this.rbunmarried.Name = "rbunmarried";
            this.rbunmarried.Size = new System.Drawing.Size(73, 17);
            this.rbunmarried.TabIndex = 0;
            this.rbunmarried.TabStop = true;
            this.rbunmarried.Text = "Unmarried";
            this.rbunmarried.UseVisualStyleBackColor = true;
            // 
            // rbmarried
            // 
            this.rbmarried.AutoSize = true;
            this.rbmarried.Location = new System.Drawing.Point(17, 20);
            this.rbmarried.Name = "rbmarried";
            this.rbmarried.Size = new System.Drawing.Size(60, 17);
            this.rbmarried.TabIndex = 0;
            this.rbmarried.TabStop = true;
            this.rbmarried.Text = "Married";
            this.rbmarried.UseVisualStyleBackColor = true;
            // 
            // btnpreview
            // 
            this.btnpreview.Location = new System.Drawing.Point(80, 295);
            this.btnpreview.Name = "btnpreview";
            this.btnpreview.Size = new System.Drawing.Size(169, 23);
            this.btnpreview.TabIndex = 7;
            this.btnpreview.Text = "Preview";
            this.btnpreview.UseVisualStyleBackColor = true;
            this.btnpreview.Click += new System.EventHandler(this.btnpreview_Click);
            // 
            // chkreading
            // 
            this.chkreading.AutoSize = true;
            this.chkreading.Location = new System.Drawing.Point(87, 195);
            this.chkreading.Name = "chkreading";
            this.chkreading.Size = new System.Drawing.Size(66, 17);
            this.chkreading.TabIndex = 8;
            this.chkreading.Text = "Reading";
            this.chkreading.UseVisualStyleBackColor = true;
            // 
            // chkpainting
            // 
            this.chkpainting.AutoSize = true;
            this.chkpainting.Location = new System.Drawing.Point(192, 195);
            this.chkpainting.Name = "chkpainting";
            this.chkpainting.Size = new System.Drawing.Size(64, 17);
            this.chkpainting.TabIndex = 8;
            this.chkpainting.Text = "Painting";
            this.chkpainting.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(329, 354);
            this.Controls.Add(this.chkpainting);
            this.Controls.Add(this.chkreading);
            this.Controls.Add(this.btnpreview);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chlcountry);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Customer Data Entry Screen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox chlcountry;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbfemale;
        private System.Windows.Forms.RadioButton rbmale;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbunmarried;
        private System.Windows.Forms.RadioButton rbmarried;
        private System.Windows.Forms.Button btnpreview;
        private System.Windows.Forms.CheckBox chkreading;
        private System.Windows.Forms.CheckBox chkpainting;
    }
}

