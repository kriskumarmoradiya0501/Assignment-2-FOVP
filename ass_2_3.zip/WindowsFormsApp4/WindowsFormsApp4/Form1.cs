﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void opr(String s)
        {
            double a = Double.Parse(txt_no1.Text);
            double b = Double.Parse(txt_no2.Text);
            if (s == "/") {
                String c = Convert.ToString(a / b);
                MessageBox.Show(c, "Divison", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (s == "*")
            {
                String c = Convert.ToString(a * b);
                MessageBox.Show(c, "Multiplication", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if(s == "-")
            {
                String c = Convert.ToString(a - b);
                MessageBox.Show(c, "Subtraction", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if(s == "+")
            {
                String c = Convert.ToString(a + b);
                MessageBox.Show(c, "Addition", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            opr(btndiv.Text);
        }

        private void btnmul_Click(object sender, EventArgs e)
        {
            opr(btnmul.Text);

        }

        private void btnmin_Click(object sender, EventArgs e)
        {
            opr(btnmin.Text);
            
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            opr(btnadd.Text);
            
        }

     
    }
}
