﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pro5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            lblname.Text = "Name : "+txtname.Text;
            lblmess.Text = "Message : "+txtmess.Text;
            if(chkbold.Checked ) { 
                lblname.Font = new Font(Font, lblname.Font.Style | FontStyle.Bold);
                lblmess.Font = new Font(Font, lblname.Font.Style | FontStyle.Bold);
            }
            if(chkitalic.Checked )
            {
                lblname.Font = new Font(Font, lblname.Font.Style | FontStyle.Italic);
                lblmess.Font = new Font(Font, lblname.Font.Style | FontStyle.Italic);
            }
            if (chkunder.Checked)
            {
                lblname.Font = new Font(Font, lblname.Font.Style | FontStyle.Underline);
                lblmess.Font = new Font(Font, lblname.Font.Style | FontStyle.Underline);
            }
            
            if (rbgreen.Checked) { 
                lblname.ForeColor= Color.Green;
                lblmess.ForeColor= Color.Green;
            }
            if (rbpink.Checked)
            {
                lblname.ForeColor = Color.Pink;
                lblmess.ForeColor= Color.Pink;
            }
            if(rbred.Checked)
            {
                lblname.ForeColor= Color.Red;
                lblmess.ForeColor= Color.Red;
            }
        }
    }
}
