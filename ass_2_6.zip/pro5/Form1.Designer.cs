﻿namespace pro5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblmess = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtmess = new System.Windows.Forms.TextBox();
            this.chkbold = new System.Windows.Forms.CheckBox();
            this.chkitalic = new System.Windows.Forms.CheckBox();
            this.chkunder = new System.Windows.Forms.CheckBox();
            this.rbred = new System.Windows.Forms.RadioButton();
            this.rbgreen = new System.Windows.Forms.RadioButton();
            this.rbpink = new System.Windows.Forms.RadioButton();
            this.btndisplay = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Name:";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(25, 254);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(44, 13);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Name : ";
            // 
            // lblmess
            // 
            this.lblmess.AutoSize = true;
            this.lblmess.Location = new System.Drawing.Point(25, 293);
            this.lblmess.Name = "lblmess";
            this.lblmess.Size = new System.Drawing.Size(62, 13);
            this.lblmess.TabIndex = 0;
            this.lblmess.Text = "Message :  ";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(112, 28);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(207, 20);
            this.txtname.TabIndex = 1;
            // 
            // txtmess
            // 
            this.txtmess.Location = new System.Drawing.Point(112, 155);
            this.txtmess.Name = "txtmess";
            this.txtmess.Size = new System.Drawing.Size(207, 20);
            this.txtmess.TabIndex = 1;
            // 
            // chkbold
            // 
            this.chkbold.AutoSize = true;
            this.chkbold.Location = new System.Drawing.Point(109, 72);
            this.chkbold.Name = "chkbold";
            this.chkbold.Size = new System.Drawing.Size(55, 17);
            this.chkbold.TabIndex = 2;
            this.chkbold.Text = "BOLD";
            this.chkbold.UseVisualStyleBackColor = true;
            // 
            // chkitalic
            // 
            this.chkitalic.AutoSize = true;
            this.chkitalic.Location = new System.Drawing.Point(171, 72);
            this.chkitalic.Name = "chkitalic";
            this.chkitalic.Size = new System.Drawing.Size(59, 17);
            this.chkitalic.TabIndex = 2;
            this.chkitalic.Text = "ITALIC";
            this.chkitalic.UseVisualStyleBackColor = true;
            // 
            // chkunder
            // 
            this.chkunder.AutoSize = true;
            this.chkunder.Location = new System.Drawing.Point(239, 72);
            this.chkunder.Name = "chkunder";
            this.chkunder.Size = new System.Drawing.Size(89, 17);
            this.chkunder.TabIndex = 2;
            this.chkunder.Text = "UNDERLINE";
            this.chkunder.UseVisualStyleBackColor = true;
            // 
            // rbred
            // 
            this.rbred.AutoSize = true;
            this.rbred.Location = new System.Drawing.Point(110, 107);
            this.rbred.Name = "rbred";
            this.rbred.Size = new System.Drawing.Size(48, 17);
            this.rbred.TabIndex = 3;
            this.rbred.TabStop = true;
            this.rbred.Text = "RED";
            this.rbred.UseVisualStyleBackColor = true;
            // 
            // rbgreen
            // 
            this.rbgreen.AutoSize = true;
            this.rbgreen.Location = new System.Drawing.Point(172, 107);
            this.rbgreen.Name = "rbgreen";
            this.rbgreen.Size = new System.Drawing.Size(63, 17);
            this.rbgreen.TabIndex = 3;
            this.rbgreen.TabStop = true;
            this.rbgreen.Text = "GREEN";
            this.rbgreen.UseVisualStyleBackColor = true;
            // 
            // rbpink
            // 
            this.rbpink.AutoSize = true;
            this.rbpink.Location = new System.Drawing.Point(240, 107);
            this.rbpink.Name = "rbpink";
            this.rbpink.Size = new System.Drawing.Size(50, 17);
            this.rbpink.TabIndex = 3;
            this.rbpink.TabStop = true;
            this.rbpink.Text = "PINK";
            this.rbpink.UseVisualStyleBackColor = true;
            // 
            // btndisplay
            // 
            this.btndisplay.Location = new System.Drawing.Point(112, 214);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.Size = new System.Drawing.Size(212, 22);
            this.btndisplay.TabIndex = 4;
            this.btndisplay.Text = "Display";
            this.btndisplay.UseVisualStyleBackColor = true;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Enter Message:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 333);
            this.Controls.Add(this.btndisplay);
            this.Controls.Add(this.rbpink);
            this.Controls.Add(this.rbgreen);
            this.Controls.Add(this.rbred);
            this.Controls.Add(this.chkunder);
            this.Controls.Add(this.chkitalic);
            this.Controls.Add(this.chkbold);
            this.Controls.Add(this.txtmess);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblmess);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblmess;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtmess;
        private System.Windows.Forms.CheckBox chkbold;
        private System.Windows.Forms.CheckBox chkitalic;
        private System.Windows.Forms.CheckBox chkunder;
        private System.Windows.Forms.RadioButton rbred;
        private System.Windows.Forms.RadioButton rbgreen;
        private System.Windows.Forms.RadioButton rbpink;
        private System.Windows.Forms.Button btndisplay;
        private System.Windows.Forms.Label label4;
    }
}

